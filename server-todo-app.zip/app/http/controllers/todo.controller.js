const createHttpError = require("http-errors");
const path = require("path");
const {CategoryModel} = require("../../models/category");
const {TodoModel} = require("../../models/todo");
const {
    copyObject,
    deleteInvalidPropertyInObject,
} = require("../../utils/functions");
const {validateAddNewPost} = require("../validators/post/post.schema");
const {CommentController} = require("./comment.controller");
const Controller = require("./controller");
const {StatusCodes: HttpStatus} = require("http-status-codes");
const {UserModel} = require("../../models/user");
const {transformPost} = require("../../utils/transformPost");
const {default: mongoose} = require("mongoose");

class TodoController extends Controller {
    constructor() {
        super();
    }

    async getAllTodos(req, res) {
       try {
           let dbQuery = {};
           const user = req.user;
           if (user && !user?._id){
               return res.status(HttpStatus.FORBIDDEN).json({
                   statusCode: HttpStatus.FORBIDDEN,
                   data: {
                       message: "لطفه ابتدا وارد حساب کاربری خود شوید",
                       todos: [],
                       totalPages:0,
                   },
               });
           }
           let {q: search, categorySlug, sort, page, limit} = req.query;
           page = page || 1;
           limit = limit || 6;
           const skip = (page - 1) * limit;

           if (search) {
               const searchTerm = new RegExp(search, "ig");
               dbQuery["$or"] = [
                   {value: searchTerm},
                   {slug: searchTerm}
               ];
           }

           // if (search) dbQuery["$text"] = { $search: search }; // -> OLD METHOD TO SEARCH BASED ON INDEX

           if (categorySlug) {
               const categories = [categorySlug].flat(2);
               const categoryIds = [];
               for (const item of categories) {
                   const {_id} = await CategoryModel.findOne({slug: item});
                   categoryIds.push(_id);
               }
               dbQuery["category"] = {
                   $in: categoryIds,
               };
           }

           const sortQuery = {};
           if (!sort) sortQuery["createdAt"] = -1;
           if (sort) {
               if (sort === "latest") sortQuery["createdAt"] = -1;
               if (sort === "earliest") sortQuery["createdAt"] = 1;
               // if (sort === "popular") sortQuery["likesCount"] = -1;
               // if (sort === "time_desc") sortQuery["readingTime"] = -1;
               // if (sort === "time_asc") sortQuery["readingTime"] = 1;
           }
           dbQuery["author"] = {
               $in: user?._id,
           };
           const posts = await TodoModel.find(dbQuery, {
               comments: 0,
           })
               .populate([
                   {path: "category", select: {title: 1, slug: 1}},
                   {path: "author", select: {name: 1}},
                   {
                       path: "related",
                       model: "Todo",
                       select: {
                           value: 1,
                           slug: 1,
                           desc: 1,
                           done:1,
                           author: 1,
                       },
                       populate: [
                           {
                               path: "author",
                               model: "User",
                               select: {name: 1},
                           },
                           {
                               path: "category",
                               model: "Category",
                               select: {title: 1, slug: 1},
                           },
                       ],
                   },
               ])
               .limit(limit)
               .skip(skip)
               .sort(sortQuery);

           const totalPages = Math.ceil(
               Number((await TodoModel.find(dbQuery)).length) / limit
           );

           const transformedPosts = copyObject(posts);

           for (const post of transformedPosts) {
               // await transformPost(post, user);
           }

           return res.status(HttpStatus.OK).json({
               statusCode: HttpStatus.OK,
               data: {
                   message: "تسک های مدنظر شما",
                   todos: transformedPosts,
                   totalPages,
               },
           });
       }catch (e) {
           console.log(e)
       }
    }

    async getPostBySlug(req, res) {
        const {slug} = req.params;
        const user = req.user;
        const post = await TodoModel.findOne({slug}).populate([
            {
                path: "author",
                model: "User",
                select: {name: 1, biography: 1, avatar: 1},
            },
            {path: "category", model: "Category", select: {title: 1, slug: 1}},
            {
                path: "related",
                model: "Post",
                select: {
                    title: 1,
                    slug: 1,
                    bfireText: 1,
                    coverImage: 1,
                    author: 1,
                },
                populate: [
                    {
                        path: "author",
                        model: "User",
                        select: {name: 1, biography: 1, avatar: 1},
                    },
                    {
                        path: "category",
                        model: "Category",
                        select: {title: 1, slug: 1},
                    },
                ],
            },
        ]);

        if (!post) throw createHttpError.NotFound("پستی با این مشخصات یافت نشد");
        const {id: postId} = post;
        const acceptedCommnets = await CommentController.findAcceptedComments(
            postId
        );

        const transformedPost = copyObject(post);

        transformedPost.comments = acceptedCommnets;
        transformedPost.commentsCount =
            acceptedCommnets.length +
            acceptedCommnets.reduce((a, c) => a + c.answers.length, 0);

        await transformPost(transformedPost, user);

        return res.status(HttpStatus.OK).json({
            statusCode: HttpStatus.OK,
            data: {
                todos: transformedPost,
            },
        });
    }

    async addNewTodo(req, res) {
        let {
            value,
            done,
            category,
            desc,
        } = req.body;
        console.log(req.body)
        const author = req.user._id;
        if (!category) {
            let {_id} = await CategoryModel.findOne({englishTitle: "all"});
            category = _id;
        }
        const _todo = await TodoModel.create({
            value,
            done,
            category,
            desc,
            slug: value,
            author
        });

        if (!_todo?._id) throw createHttpError.InternalServerError("تسک ثبت نشد");

        return res.status(HttpStatus.CREATED).json({
            statusCode: HttpStatus.CREATED,
            data: {
                message: "تسک با موفقیت ایجاد شد",
                todo: _todo,
            },
        });
    }

    async updatePost(req, res) {
        const {id} = req.params;
        // const {value , done,desc ,category} = req.body;
        const {...rest} = req.body;

        const post = await this.findPostById(id);
        const data = copyObject(rest);

        const updatePostResult = await TodoModel.updateOne(
            {_id: id},
            {
                $set: {...data}
            }
        );

        if (!updatePostResult.modifiedCount)
            throw new createHttpError.InternalServerError(
                "به روزرسانی تسک انجام نشد"
            );

        return res.status(HttpStatus.OK).json({
            statusCode: HttpStatus.OK,
            data: {
                message: "به روزرسانی تسک با موفقیت انجام شد",
            },
        });
    }

    async removePost(req, res) {
        const {id} = req.params;
        await this.findPostById(id);
        const post = await TodoModel.findByIdAndDelete(id);
        if (!post._id) throw createHttpError.InternalServerError(" پست حذف نشد");
        return res.status(HttpStatus.OK).json({
            statusCode: HttpStatus.OK,
            data: {
                message: "تسک با موفقیت حذف شد",
            },
        });
    }

    async getPostById(req, res) {
        const {id} = req.params;
        const post = await this.findPostById(id);
        req.params.slug = post.slug;
        await this.getPostBySlug(req, res);
    }

    async findPostById(id) {
        if (!mongoose.isValidObjectId(id))
            throw createHttpError.BadRequest("شناسه پست نامعتبر است");

        const post = await TodoModel.findById(id);
        if (!post) throw createHttpError.BadRequest("پست با این مشخصات یافت نشد");
        return copyObject(post);
    }

    async likePost(req, res) {
        const {id: postId} = req.params;
        const user = req.user;
        const post = await this.findPostById(postId);
        const likedPost = await TodoModel.findOne({
            _id: postId,
            likes: user._id,
        });
        const updatePostQuery = likedPost
            ? {$pull: {likes: user._id}}
            : {$push: {likes: user._id}};

        const updateUserQuery = likedPost
            ? {$pull: {likedPosts: post._id}}
            : {$push: {likedPosts: post._id}};

        const postUpdate = await TodoModel.updateOne(
            {_id: postId},
            updatePostQuery
        );
        const userUpdate = await UserModel.updateOne(
            {_id: user._id},
            updateUserQuery
        );

        if (postUpdate.modifiedCount === 0 || userUpdate.modifiedCount === 0)
            throw createHttpError.BadRequest("عملیات ناموفق بود.");

        let message;
        if (!likedPost) {
            message = "مرسی بابت لایک تون";
        } else message = "لایک شما برداشته شد";

        return res.status(HttpStatus.OK).json({
            statusCode: HttpStatus.OK,
            data: {
                message,
            },
        });
    }

    async bookmarkPost(req, res) {
        const {id: postId} = req.params;
        const user = req.user;
        const post = await this.findPostById(postId);
        const likedPost = await TodoModel.findOne({
            _id: postId,
            bookmarks: user._id,
        });
        const updatePostQuery = likedPost
            ? {$pull: {bookmarks: user._id}}
            : {$push: {bookmarks: user._id}};

        const updateUserQuery = likedPost
            ? {$pull: {bookmarkedPosts: post._id}}
            : {$push: {bookmarkedPosts: post._id}};

        const postUpdate = await TodoModel.updateOne(
            {_id: postId},
            updatePostQuery
        );
        const userUpdate = await UserModel.updateOne(
            {_id: user._id},
            updateUserQuery
        );

        if (postUpdate.modifiedCount === 0 || userUpdate.modifiedCount === 0)
            throw createHttpError.BadRequest("عملیات ناموفق بود.");

        let message;
        if (!likedPost) {
            message = "پست بوکمارک شد";
        } else message = "پست از بوکمارک برداشته شد";

        return res.status(HttpStatus.OK).json({
            statusCode: HttpStatus.OK,
            data: {
                message,
            },
        });
    }
}

module.exports = {
    TodoController: new TodoController(),
};
