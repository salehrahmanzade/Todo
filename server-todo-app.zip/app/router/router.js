const { verifyAccessToken } = require("../http/middlewares/auth.middleware");
const { userAuthRoutes } = require("./auth");
const { categoryRoutes } = require("./category");
const { todoRoutes } = require("./todo");
const router = require("express").Router();

router.use("/user", userAuthRoutes);
router.use("/todo", todoRoutes);
router.use("/category", categoryRoutes);

module.exports = router;
