const expressAsyncHandler = require("express-async-handler");
const {
    verifyAccessToken,
    decideAuthMiddleware,
} = require("../http/middlewares/auth.middleware");
const {TodoController} = require("../http/controllers/todo.controller");
const {uploadFile} = require("../utils/multer");
const router = require("express").Router();

router.post(
    "/create",
    verifyAccessToken,
    expressAsyncHandler(TodoController.addNewTodo)
);
router.patch(
    "/update/:id",
    verifyAccessToken,
    uploadFile.single("coverImage"),
    expressAsyncHandler(TodoController.updatePost)
);
router.get(
    "/list",
    decideAuthMiddleware,
    expressAsyncHandler(TodoController.getAllTodos)
);
router.delete(
    "/remove/:id",
    verifyAccessToken,
    expressAsyncHandler(TodoController.removePost)
);

router.get(
    "/slug/:slug",
    decideAuthMiddleware,
    expressAsyncHandler(TodoController.getPostBySlug)
);

router.post(
    "/like/:id",
    verifyAccessToken,
    expressAsyncHandler(TodoController.likePost)
);

router.post(
    "/bookmark/:id",
    verifyAccessToken,
    expressAsyncHandler(TodoController.bookmarkPost)
);

router.get(
    "/:id",
    decideAuthMiddleware,
    expressAsyncHandler(TodoController.getPostById)
);

module.exports = {
    todoRoutes: router,
};
