const { CommentController } = require("../http/controllers/comment.controller");

async function transformPost(post, user) {
  return post;
}

module.exports = {
  transformPost,
};
