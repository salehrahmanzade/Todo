const mongoose = require("mongoose");
const ObjectId = mongoose.Schema.Types.ObjectId;

const TodoSchema = new mongoose.Schema(
    {
        value: {type: String, required: true},
        done: {type: Boolean, default: false},
        slug: {type: String, required: true, unique: true},
        category: {
            type: ObjectId,
            ref: "Category",
            required: true,
        },
        desc: {type: String, default: " "},
        author: {type: ObjectId, ref: "User"},
        related: [{ type: ObjectId, ref: "Todo" }],
    },
    {
        timestamps: true,
        toJSON: {
            virtuals: true,
        },
    }
);
module.exports = {
    TodoModel: mongoose.model("Todo", TodoSchema),
};
