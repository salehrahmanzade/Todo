
async function LatestPosts() {
  const query = "sort=latest&limit=5";
  return <div></div>;
}
export default LatestPosts;
