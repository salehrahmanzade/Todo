export function toLocalDateShort(date) {
  return new Date(date).toLocaleDateString("fa-IR", {});
}
