export interface OptionHttpObject {
    headers: object,
    credentials: string,
    method: string
}